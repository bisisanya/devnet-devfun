|   Date        |   Author          |   Version |
|   :---        |   :---            |   :---    |
|   2025-Jan-10 |   Dexter King     |   1.1     |

<br>

## Update from last author
Finalized the 'Config Cisco Devices from Text File' solution. Currently the solution utilizes the inventory files on the 'inventories' repository which can be found [here](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_git/inventories). The [playbook](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_git/ansible-cisco?path=/playbooks/config_devices_from_file.yml) is ran inside of the [pipeline](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_build?definitionId=3874&_a=summary) which is backed by this [pipeline file](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_git/ansible-cisco?path=/pipelines/config_devices_from_file.yml). 

<br />

## Notes
The 'Config Cisco Devices from Text File' pipeline uses <u> only 1</u> of the config files on the main directory of the ansible-cisco repository <u>per pipeline run</u>. These filenames (generic_XXXX_config.txt) correspond with the groups (breeze_XXXX) inside the inventory files.  
<br />
For example, if the pipeline user selects <strong><u>breeze</u></strong> and <strong><u>ios</u></strong> device type on the pipeline UI parameters when running the pipeline, then the following is the automation's interpretation..  

- use the [breeze_inventory.yml](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_git/inventories?path=/breeze_inventory.yml) inventory file from the [inventories repo](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_git/inventories)  

- target the breeze_ios (currently line 11) group inside [breeze_inventory.yml](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_git/inventories?path=/breeze_inventory.yml) 

- use the [generic_ios_config.txt](./generic_ios_config.txt) for the commands to run  

- use breeze (brneteng2) [pipeline agent](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_settings/agentqueues?agentId=28614&queueId=7306&view=capabilities) to perform the work  

<br />

## Ansible Roles/Tasks
|   Role Name                                                                                       |   Purpose                                                                                                 |
|   :---                                                                                            |   :---                                                                                                    |
|   [ansibleuser_set](./roles/ansibleuser_set/tasks/main.yml)                                       |   Set the ansible user and password from a provided variable                                              |
|   [command_show_uptime](./roles/command_show_uptime/tasks/main.yml)                               |   Retrieves the uptime from a device                                                                      | 
|   [command_show_version](./roles/command_show_version/tasks/main.yml)                             |   Issues and displays "show version l i Software,"                                                        | 
|   [config_add_from_file](./roles/config_add_from_file/tasks/main.yml)                             |   Uses the appropriate config file on the main directory to configure a group of devices in the inventory |
|   [config_add_from_file_email_format](./roles/config_add_from_file_email_format/tasks/main.yml)   |   Formats the email contents from the variables created in the config_add_from_file role                  |
|   [email_send](./roles/email_send/tasks/main.yml)                                                 |   Single task to send email using SMTP relay                                                              |
|   [git_clone_inventory_repo](./roles/git_clone_inventory_repo/tasks/main.yml)                     |   Tasks to git clone the inventory repository. *uses the git credentials in NetAuth variable group     |

<br />

## Ansible Playbooks
|   Playbook Name                                                               |   Purpose                                                                                 |
|   :---                                                                        |   :---                                                                                    |
|   [clone_inventory_repo.yml](./playbooks/clone_inventory_repo.yml)            |   Clone the inventory repository to the agent running the pipeline                        |
|   [config_devices_from_file.yml](./playbooks/config_devices_from_file.yml)    |   Configure group of devices in the inventory file based on commands saved in text file   |
|   [get_device_info.yml](./playbooks/get_device_info.yml)                      |   Collect the device uptime and software version, then display them during the run

<br />

## Pipelines
|   Pipeline    |   Pipeline YML File   |   Demo    |
|   :---        |   :---                |   :---    |
|   [Configure Devices from Text File](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_build?definitionId=3874)   | [config_devices_from_file.yml](./pipelines/config_devices_from_file.yml)  | 
|   [Get Info From Inventory Devices](https://carnivalcruiselines.visualstudio.com/CCL%20Network%20Satellite/_build?definitionId=3871)    | [get_device_info.yml](./pipelines/get_device_info.yml)                    |   
